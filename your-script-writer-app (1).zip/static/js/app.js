// Global state management with character persistence
const storyData = {
    language: '',
    storyType: '',
    genre: '',
    idea: '',
    setting: '',
    tone: '',
    ending: '',
    characters: [],
    platform: '',
    contentType: '',
    targetAudience: ''
};

// Character backup for persistence across navigation
let characterBackup = [];

// Force character field styling on page load
document.addEventListener('DOMContentLoaded', function() {
    fixCharacterFields();
    
    // Re-fix every 100ms for first 3 seconds to ensure proper rendering
    let fixAttempts = 0;
    const fixInterval = setInterval(() => {
        fixCharacterFields();
        fixAttempts++;
        if (fixAttempts >= 30) {
            clearInterval(fixInterval);
        }
    }, 100);
});

function fixCharacterFields() {
    const characterDescription = document.getElementById('character-description');
    
    if (characterDescription) {
        // Check if element is being rendered as textarea
        if (characterDescription.tagName.toLowerCase() === 'textarea') {
            // Replace textarea with input element
            const newInput = document.createElement('input');
            newInput.type = 'text';
            newInput.id = 'character-description';
            newInput.placeholder = 'e.g., Young chef from Delhi';
            newInput.value = characterDescription.value;
            newInput.autocomplete = 'off';
            newInput.spellcheck = false;
            
            // Copy all styling
            newInput.style.cssText = 'flex: 1; width: 100%; height: 56px; padding: 16px; border-radius: 15px; border: 1px solid rgba(255, 255, 255, 0.1); background: rgba(30, 30, 46, 0.8); color: #ffb3d9; font-size: 1rem; box-sizing: border-box;';
            
            // Replace the element
            characterDescription.parentNode.replaceChild(newInput, characterDescription);
            console.log('Replaced textarea with input element');
        } else {
            // Force input styling
            characterDescription.style.cssText = 'flex: 1; width: 100%; height: 56px; padding: 16px; border-radius: 15px; border: 1px solid rgba(255, 255, 255, 0.1); background: rgba(30, 30, 46, 0.8); color: #ffb3d9; font-size: 1rem; box-sizing: border-box;';
            characterDescription.setAttribute('type', 'text');
            characterDescription.removeAttribute('rows');
            characterDescription.removeAttribute('cols');
            console.log('Fixed input element styling');
        }
    }
}

// Screen navigation functions
function nextScreen(screenId) {
    const currentScreen = document.querySelector('.screen.active');
    let targetScreenId = screenId;
    
    // Special routing for social media content
    if (storyData.storyType === 'social_content') {
        if (screenId === 'details-screen') {
            targetScreenId = 'social-content-screen';
        }
    }
    
    const nextScreen = document.getElementById(targetScreenId);
    
    if (currentScreen) {
        currentScreen.classList.remove('active');
    }
    
    if (nextScreen) {
        nextScreen.classList.add('active');
        
        // Fix character fields when navigating to characters screen
        if (targetScreenId === 'characters-screen') {
            setTimeout(fixCharacterFields, 50);
        }
        
        // Special handling for summary screen
        if (targetScreenId === 'summary-screen') {
            // Always restore characters from backup to ensure persistence
            if (characterBackup.length > 0) {
                storyData.characters = [...characterBackup];
                console.log('Restored characters before summary:', storyData.characters);
            }
            console.log('Navigating to summary. Characters before updateSummary():', storyData.characters);
            updateSummary();
        }
        
        // Update characters list when entering characters screen
        if (targetScreenId === 'characters-screen') {
            // Restore characters from backup if available
            if (characterBackup.length > 0 && storyData.characters.length === 0) {
                storyData.characters = [...characterBackup];
                console.log('Restored characters from backup:', storyData.characters);
            }
            updateCharactersList();
        }
    }
}

function previousScreen(screenId) {
    nextScreen(screenId);
}

function startOver() {
    // Reset all data
    Object.keys(storyData).forEach(key => {
        if (key === 'characters') {
            storyData[key] = [];
        } else {
            storyData[key] = '';
        }
    });
    
    // Clear form inputs
    const storyIdeaEl = document.getElementById('story-idea');
    const settingEl = document.getElementById('setting');
    const toneEl = document.getElementById('tone');
    const endingEl = document.getElementById('ending');
    const charNameEl = document.getElementById('character-name');
    const charDescEl = document.getElementById('character-description');
    const socialIdeaEl = document.getElementById('social-story-idea');
    const platformEl = document.getElementById('platform');
    const contentTypeEl = document.getElementById('content-type');
    const targetAudienceEl = document.getElementById('target-audience');
    
    if (storyIdeaEl) storyIdeaEl.value = '';
    if (settingEl) settingEl.value = '';
    if (toneEl) toneEl.value = '';
    if (endingEl) endingEl.value = '';
    if (charNameEl) charNameEl.value = '';
    if (charDescEl) charDescEl.value = '';
    if (socialIdeaEl) socialIdeaEl.value = '';
    if (platformEl) platformEl.value = '';
    if (contentTypeEl) contentTypeEl.value = '';
    if (targetAudienceEl) targetAudienceEl.value = '';
    
    // Clear characters list
    document.getElementById('characters-list').innerHTML = '';
    
    // Remove all selections
    document.querySelectorAll('.option-card.selected').forEach(card => {
        card.classList.remove('selected');
    });
    
    // Disable next buttons
    document.getElementById('language-next-btn').disabled = true;
    document.getElementById('story-type-next-btn').disabled = true;
    document.getElementById('genre-next-btn').disabled = true;
    
    // Go to welcome screen
    nextScreen('welcome-screen');
}

// Selection functions
function selectLanguage(language) {
    storyData.language = language;
    
    // Update UI
    document.querySelectorAll('#language-screen .option-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    event.target.closest('.option-card').classList.add('selected');
    document.getElementById('language-next-btn').disabled = false;
}

function selectStoryType(type) {
    // Store existing characters before changing story type
    const existingCharacters = [...storyData.characters];
    
    storyData.storyType = type;
    
    // Restore characters if they were previously added
    if (existingCharacters.length > 0) {
        storyData.characters = existingCharacters;
    }
    
    // Update UI
    document.querySelectorAll('#story-type-screen .option-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    event.target.closest('.option-card').classList.add('selected');
    document.getElementById('story-type-next-btn').disabled = false;
}

function selectGenre(genre) {
    storyData.genre = genre;
    
    // Update UI
    document.querySelectorAll('#genre-screen .option-card').forEach(card => {
        card.classList.remove('selected');
    });
    
    event.target.closest('.option-card').classList.add('selected');
    document.getElementById('genre-next-btn').disabled = false;
}

function validateSocialContent() {
    // Collect social media form data
    const platform = document.getElementById('platform').value;
    const contentType = document.getElementById('content-type').value;
    const targetAudience = document.getElementById('target-audience').value;
    const socialIdea = document.getElementById('social-story-idea').value.trim();
    
    // Validate required fields
    if (!platform) {
        alert('Please select a platform');
        return;
    }
    
    if (!contentType) {
        alert('Please select a content type');
        return;
    }
    
    if (!targetAudience) {
        alert('Please select a target audience');
        return;
    }
    
    if (!socialIdea) {
        alert('Please provide your content idea');
        return;
    }
    
    // Store the data
    storyData.platform = platform;
    storyData.contentType = contentType;
    storyData.targetAudience = targetAudience;
    storyData.idea = socialIdea;
    
    // Proceed to characters screen
    nextScreen('characters-screen');
}

function goBackFromCharacters() {
    if (storyData.storyType === 'social_content') {
        nextScreen('social-content-screen');
    } else {
        nextScreen('details-screen');
    }
}

function proceedFromCharacters() {
    console.log('Proceeding from characters. Current characters:', storyData.characters);
    console.log('Full storyData before summary:', JSON.stringify(storyData, null, 2));
    
    if (storyData.characters.length === 0) {
        // Show the recommendation prompt
        const promptElement = document.getElementById('character-prompt');
        if (promptElement) {
            promptElement.style.display = 'block';
        }
        
        // Show confirmation dialog for proceeding without characters
        const proceed = confirm('You haven\'t added any characters yet. Characters make your content more engaging and relatable.\n\nWould you like to continue without characters, or go back to add some?');
        
        if (!proceed) {
            // User wants to add characters, keep them on the characters screen
            return;
        }
    }
    
    // Proceed to summary screen
    nextScreen('summary-screen');
}

// Character management
function addQuickCharacter(name, description) {
    console.log('Adding quick character:', name, description);
    // Check if character already exists
    if (storyData.characters.some(char => char.name.toLowerCase() === name.toLowerCase())) {
        alert(`Character "${name}" already exists`);
        return;
    }
    
    // Add character
    storyData.characters.push({ name, description });
    // Backup characters for persistence
    characterBackup = [...storyData.characters];
    console.log('Characters after adding:', storyData.characters);
    
    // Hide the recommendation prompt if it was showing
    const promptElement = document.getElementById('character-prompt');
    if (promptElement) {
        promptElement.style.display = 'none';
    }
    
    // Update characters list
    updateCharactersList();
}

function addCharacter() {
    console.log('Manual addCharacter called');
    const name = document.getElementById('character-name').value.trim();
    const description = document.getElementById('character-description').value.trim();
    
    console.log('Manual character input:', name, description);
    
    if (!name) {
        alert('Please enter a character name');
        return;
    }
    
    // Check if character already exists
    if (storyData.characters.some(char => char.name.toLowerCase() === name.toLowerCase())) {
        alert('A character with this name already exists');
        return;
    }
    
    // Add character
    storyData.characters.push({ name, description });
    // Backup characters for persistence
    characterBackup = [...storyData.characters];
    console.log('Characters after manual adding:', storyData.characters);
    
    // Clear inputs
    document.getElementById('character-name').value = '';
    document.getElementById('character-description').value = '';
    
    // Hide the recommendation prompt if it was showing
    const promptElement = document.getElementById('character-prompt');
    if (promptElement) {
        promptElement.style.display = 'none';
    }
    
    // Update characters list
    updateCharactersList();
}

function removeCharacter(index) {
    storyData.characters.splice(index, 1);
    // Update backup to reflect removal
    characterBackup = [...storyData.characters];
    updateCharactersList();
}

function updateCharactersList() {
    const container = document.getElementById('characters-list');
    
    if (storyData.characters.length === 0) {
        container.innerHTML = '<p class="text-center" style="color: var(--text-secondary); font-style: italic;">No characters added yet</p>';
        return;
    }
    
    container.innerHTML = storyData.characters.map((char, index) => `
        <div class="character-item">
            <button class="character-remove" onclick="removeCharacter(${index})">×</button>
            <h4>${char.name}</h4>
            <p>${char.description || 'No description provided'}</p>
        </div>
    `).join('');
}

// Manual character addition function
function addManualCharacter() {
    const nameEl = document.getElementById('character-name');
    const descEl = document.getElementById('character-description');
    
    if (!nameEl || !descEl) {
        alert('Error: Could not find character input fields');
        return;
    }
    
    const name = nameEl.value.trim();
    const description = descEl.value.trim();
    
    if (!name) {
        alert('Please enter a character name');
        return;
    }
    
    // Check if character already exists
    if (storyData.characters.some(char => char.name.toLowerCase() === name.toLowerCase())) {
        alert(`Character "${name}" already exists`);
        return;
    }
    
    // Add character
    storyData.characters.push({name, description});
    // Backup characters for persistence
    characterBackup = [...storyData.characters];
    
    // Clear inputs
    nameEl.value = '';
    descEl.value = '';
    
    // Hide the recommendation prompt if it was showing
    const promptElement = document.getElementById('character-prompt');
    if (promptElement) {
        promptElement.style.display = 'none';
    }
    
    // Update characters list
    updateCharactersList();
}

// Summary update
function updateSummary() {
    // Get current form values based on story type
    if (storyData.storyType === 'social_content') {
        // Get social media specific inputs
        const socialIdeaElement = document.getElementById('social-story-idea');
        const platformElement = document.getElementById('platform');
        const contentTypeElement = document.getElementById('content-type');
        const targetAudienceElement = document.getElementById('target-audience');
        
        if (socialIdeaElement) storyData.idea = socialIdeaElement.value.trim();
        if (platformElement) storyData.platform = platformElement.value;
        if (contentTypeElement) storyData.contentType = contentTypeElement.value;
        if (targetAudienceElement) storyData.targetAudience = targetAudienceElement.value;
        
        // Set appropriate defaults for social content
        storyData.setting = 'Social Media Platform';
        storyData.tone = storyData.tone || 'Engaging';
        storyData.ending = storyData.ending || 'Call to Action';
    } else {
        // Get regular story inputs
        const storyIdeaElement = document.getElementById('story-idea');
        const settingElement = document.getElementById('setting');
        const toneElement = document.getElementById('tone');
        const endingElement = document.getElementById('ending');
        
        if (storyIdeaElement) storyData.idea = storyIdeaElement.value.trim();
        if (settingElement) storyData.setting = settingElement.value.trim();
        if (toneElement) storyData.tone = toneElement.value;
        if (endingElement) storyData.ending = endingElement.value;
    }
    
    const summaryContainer = document.getElementById('story-summary');
    
    // Generate different summary based on story type
    if (storyData.storyType === 'social_content') {
        // Ensure characters are restored from backup if needed
        if (storyData.characters.length === 0 && characterBackup.length > 0) {
            storyData.characters = [...characterBackup];
        }
        console.log('Debug: Characters in summary:', storyData.characters);
        
        const charactersDisplay = storyData.characters.length > 0 ? 
            storyData.characters.map(c => c.name).join(', ') : 'None added';
            
        summaryContainer.innerHTML = `
            <div class="summary-item">
                <span class="summary-label">Language:</span>
                <span class="summary-value">${storyData.language || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Story Type:</span>
                <span class="summary-value">${storyData.storyType || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Genre:</span>
                <span class="summary-value">${storyData.genre || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Platform:</span>
                <span class="summary-value">${storyData.platform || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Content Type:</span>
                <span class="summary-value">${storyData.contentType || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Target Audience:</span>
                <span class="summary-value">${storyData.targetAudience || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Content Idea:</span>
                <span class="summary-value">${storyData.idea || 'Not provided'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Characters:</span>
                <span class="summary-value">${charactersDisplay}</span>
            </div>
        `;
    } else {
        summaryContainer.innerHTML = `
            <div class="summary-item">
                <span class="summary-label">Language:</span>
                <span class="summary-value">${storyData.language || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Story Type:</span>
                <span class="summary-value">${storyData.storyType || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Genre:</span>
                <span class="summary-value">${storyData.genre || 'Not selected'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Story Idea:</span>
                <span class="summary-value">${storyData.idea || 'Not provided'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Setting:</span>
                <span class="summary-value">${storyData.setting || 'Not specified'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Tone:</span>
                <span class="summary-value">${storyData.tone || 'Not specified'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Ending:</span>
                <span class="summary-value">${storyData.ending || 'Not specified'}</span>
            </div>
            <div class="summary-item">
                <span class="summary-label">Characters:</span>
                <span class="summary-value">${storyData.characters.length > 0 ? storyData.characters.map(c => c.name).join(', ') : 'None added'}</span>
            </div>
        `;
    }
}

// Story generation
async function generateStory() {
    // Validate required fields
    if (!storyData.language) {
        alert('Please select a language');
        nextScreen('language-screen');
        return;
    }
    
    if (!storyData.storyType) {
        alert('Please select a story type');
        nextScreen('story-type-screen');
        return;
    }
    
    if (!storyData.genre) {
        alert('Please select a genre');
        nextScreen('genre-screen');
        return;
    }
    
    // Get current idea value based on story type
    if (storyData.storyType === 'social_content') {
        storyData.idea = document.getElementById('social-story-idea').value.trim();
        storyData.platform = document.getElementById('platform').value;
        storyData.contentType = document.getElementById('content-type').value;
        storyData.targetAudience = document.getElementById('target-audience').value;
        
        if (!storyData.idea) {
            alert('Please provide your content idea');
            nextScreen('social-content-screen');
            return;
        }
    } else {
        storyData.idea = document.getElementById('story-idea').value.trim();
        
        if (!storyData.idea) {
            alert('Please provide your story idea');
            nextScreen('details-screen');
            return;
        }
    }
    
    // Get other form values
    storyData.setting = document.getElementById('setting') ? document.getElementById('setting').value.trim() : '';
    storyData.tone = document.getElementById('tone') ? document.getElementById('tone').value : '';
    storyData.ending = document.getElementById('ending') ? document.getElementById('ending').value : '';
    
    // Show loading screen
    nextScreen('loading-screen');
    
    try {
        const response = await fetch('/generate-script', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(storyData)
        });
        
        const result = await response.json();
        
        if (response.ok && result.success) {
            // Show the generated story
            document.getElementById('generated-story').textContent = result.script;
            nextScreen('result-screen');
        } else {
            // Show error
            document.getElementById('error-message').textContent = result.error || 'An unexpected error occurred';
            nextScreen('error-screen');
        }
    } catch (error) {
        console.error('Error generating story:', error);
        document.getElementById('error-message').textContent = 'Network error: Unable to connect to the server. Please check your connection and try again.';
        nextScreen('error-screen');
    }
}

// Download functionality
function downloadStory() {
    const storyContent = document.getElementById('generated-story').textContent;
    
    if (!storyContent) {
        alert('No story to download');
        return;
    }
    
    const blob = new Blob([storyContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    
    a.href = url;
    a.download = `${storyData.genre}-${storyData.storyType}-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// Event listeners
document.addEventListener('DOMContentLoaded', function() {
    // Initialize character list
    updateCharactersList();
    
    // Add enter key support for character addition
    document.getElementById('character-name').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            addCharacter();
        }
    });
    
    document.getElementById('character-description').addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && e.ctrlKey) {
            addCharacter();
        }
    });
});

import os
import logging
from flask import Flask, request, jsonify, render_template, session
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from werkzeug.middleware.proxy_fix import ProxyFix
try:
    import google.generativeai as genai
except ImportError:
    genai = None
import time

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize the app with the database extension
db.init_app(app)

# Configure Gemini API
if genai and os.environ.get('GEMINI_API_KEY'):
    genai.configure(api_key=os.environ.get('GEMINI_API_KEY'))

# Initialize authentication
from replit_auth import make_replit_blueprint
from flask_login import current_user

app.register_blueprint(make_replit_blueprint(), url_prefix="/auth")

# Make session permanent
@app.before_request
def make_session_permanent():
    session.permanent = True

# Initialize database tables
with app.app_context():
    import models
    db.create_all()

@app.route('/')
def index():
    """Render the main story generator interface"""
    return render_template('index.html')

@app.route('/generate-script', methods=['POST'])
def generate_script():
    """Generate script using Gemini AI based on user inputs"""
    start_time = time.time()
    
    try:
        from models import Story, Character, GenerationLog
        
        data = request.get_json()
        
        # Extract parameters from request
        language = data.get('language', 'English')
        user_idea = data.get('idea', '')
        story_type = data.get('storyType', 'story')
        genre = data.get('genre', '')
        setting = data.get('setting', '')
        characters = data.get('characters', [])
        tone = data.get('tone', '')
        ending = data.get('ending', '')
        
        # Validate required inputs
        if not user_idea.strip():
            return jsonify({'error': 'Story idea is required'}), 400
        
        if not genre:
            return jsonify({'error': 'Genre selection is required'}), 400

        # Enhanced character processing for better integration
        character_descriptions = []
        character_names = []
        for char in characters:
            if char.get('name') and char.get('description'):
                name = char['name'].strip()
                desc = char['description'].strip()
                character_names.append(name)
                character_descriptions.append(f"{name}: {desc}")
        
        character_text = '; '.join(character_descriptions) if character_descriptions else 'No specific characters defined'
        main_character_name = character_names[0] if character_names else ('नायक' if language == 'Hindi' else 'protagonist')
        all_character_names = ', '.join(character_names) if character_names else ''
        
        # Ensure character names are properly formatted for Indian context
        if character_names and story_type == 'social_content':
            creator_display_name = main_character_name

        # Create enhanced prompt based on story type
        if story_type == 'panchatantra':
            prompt = f"""
            Create an authentic Panchatantra-style story in {language} language with the following specifications:
            
            **Story Details:**
            - Genre: {genre}
            - Setting: {setting if setting else 'Ancient Indian forest or kingdom'}
            - Characters: {character_text} (focus on animals with human-like wisdom)
            - Tone: {tone if tone else 'Wisdom-filled and engaging'}
            - Ending Style: {ending if ending else 'Clear moral teaching'}
            - Central Plot: {user_idea}
            
            **PANCHATANTRA REQUIREMENTS:**
            - Use animal characters as main protagonists (like crow, fox, lion, rabbit, etc.)
            - Include a clear moral lesson or life wisdom
            - Traditional Indian storytelling style with Sanskrit influence
            - Embed practical life advice within the narrative
            - Include dialogue that sounds natural and wise
            - Reference Indian cultural values and wisdom traditions
            
            **STORY STRUCTURE:**
            - Begin with setting introduction and character establishment
            - Present a problem or conflict that requires wisdom to solve
            - Show characters making choices (good and bad)
            - Demonstrate consequences of actions
            - End with a clear moral lesson that applies to human life
            - Include a memorable teaching that readers can apply
            
            Generate a complete Panchatantra story that teaches valuable life lessons through engaging animal characters.
            """
        elif story_type == 'social_content':
            # Get additional social media parameters
            platform = data.get('platform', 'Multi-platform')
            content_type = data.get('contentType', 'Story Script')
            target_audience = data.get('targetAudience', 'General Indian')
            
            # Language-specific instructions
            language_instruction = ""
            if language == 'Hindi':
                language_instruction = "अत्यंत महत्वपूर्ण: संपूर्ण कंटेंट केवल हिंदी भाषा में लिखें। सभी संवाद, कैप्शन, और हैशटैग देवनागरी लिपि में होने चाहिए।"
            else:
                language_instruction = f"CRITICAL REQUIREMENT: Generate ALL content exclusively in {language} language."
            
            prompt = f"""
            {language_instruction}
            
            Create an extremely advanced, culturally authentic social media content package specifically designed for Indian audiences and creators:
            
            **Content Specifications:**
            - Platform: {platform} (optimized for Indian algorithms)
            - Content Type: {content_type}
            - Target Audience: {target_audience}
            - Genre: {genre}
            - Main Creator: {main_character_name} ({character_text})
            - Cultural Tone: {tone if tone else 'Authentic Indian with modern appeal'}
            - Core Concept: {user_idea}
            
            **MANDATORY CHARACTER PROMINENCE:**
            {main_character_name} must be the central figure throughout all content. Use their name in every section, create character-specific hooks, and build content around their personality and story.
            
            **COMPREHENSIVE INDIAN SOCIAL MEDIA REQUIREMENTS:**
            
            **CULTURAL AUTHENTICITY MANDATES:**
            - Integrate authentic Indian family values, traditions, and social dynamics
            - Include region-specific cultural elements (festivals, food, customs, languages)
            - Reference Indian pop culture, Bollywood, cricket, and current trending topics
            - Use Indian humor styles (family jokes, situational comedy, relatable struggles)
            - Include generational gaps and family dynamics common in Indian households
            - Add spiritual/philosophical elements resonant with Indian audiences
            - Reference Indian social media trends, memes, and viral formats
            
            **ADVANCED PRODUCTION PACKAGE (12 COMPONENTS):**
            1. **Master Shooting Script**: 60-90 second detailed breakdown with {main_character_name} as focus
            2. **Multi-Camera Setup**: Primary, backup, and B-roll camera positions featuring {main_character_name}
            3. **Authentic Indian Props**: Traditional and modern items for genuine cultural representation
            4. **Regional Wardrobe Guide**: State-specific clothing options for {main_character_name}
            5. **Lighting for Indian Skin Tones**: Professional setup recommendations
            6. **Audio Package**: Indian music genres, sound effects, and regional languages
            7. **Location Scouting**: Home, street, market, and cultural venue options
            8. **Character-Driven Caption Matrix**: 10+ caption variations featuring {main_character_name}
            9. **Engagement Ecosystem**: Community building around {main_character_name}'s brand
            10. **Viral Mechanics**: Indian-specific shareability factors and trending elements
            11. **Content Series Blueprint**: 20+ follow-up ideas with {main_character_name}
            12. **Monetization Strategy**: Brand collaboration and sponsorship opportunities
            
            **INDIAN ALGORITHM OPTIMIZATION:**
            - Prime posting times for Indian audiences (7-9 PM IST)
            - Hindi/English code-switching patterns for maximum reach
            - Regional festival and celebration tie-ins
            - Cricket season and Bollywood release correlations
            - Indian social issues and trending conversations integration
            - Family-friendly content that spans age groups (15-45)
            
            **CREATOR ECOSYSTEM BUILDING:**
            - Position {main_character_name} as relatable Indian personality
            - Create signature catchphrases and content formats for {main_character_name}
            - Build parasocial relationships through consistent {main_character_name} appearances
            - Develop {main_character_name}'s unique perspective on Indian life
            - Establish {main_character_name} as thought leader in their niche
            
            **TECHNICAL SPECIFICATIONS FOR INDIAN MARKET:**
            - Mobile-first editing for Indian smartphone users
            - Data-conscious video compression for 3G/4G networks
            - Subtitle integration for multilingual audiences
            - Accessibility features for diverse Indian demographics
            - Cross-platform optimization (Instagram, YouTube Shorts, Facebook Reels)
            
            Generate a comprehensive, culturally-authentic social media production ecosystem specifically designed for Indian creators and audiences, with {main_character_name} as the central brand personality.
            """
        else:
            # Language-specific instructions for regular stories
            language_instruction = ""
            if language == 'Hindi':
                language_instruction = "CRITICAL: Write the ENTIRE story in HINDI language using Devanagari script. All narrative, dialogue, descriptions must be in Hindi only."
            else:
                language_instruction = f"CRITICAL: Write the ENTIRE story in {language} language only."
            
            prompt = f"""
            {language_instruction}
            
            Create an exceptionally detailed, lengthy, and addictive {story_type} specifically for Indian audiences with the following specifications:
        
        **Story Details:**
        - Genre: {genre}
        - Setting: {setting if setting else 'Modern India with cultural depth'}
        - Main Character: {main_character_name} 
        - All Characters: {character_text}
        - Tone: {tone if tone else 'Emotionally rich and engaging'}
        - Ending Style: {ending if ending else 'Captivating conclusion'}
        - Central Plot: {user_idea}
        
        **CHARACTER INTEGRATION MANDATE:**
        The story must prominently feature {main_character_name} as the main protagonist. Use their name frequently throughout the narrative. If other characters are provided ({all_character_names}), integrate them meaningfully into the plot with proper character development.
        
        **INDIAN CULTURAL REQUIREMENTS:**
        - Include authentic Indian family dynamics, traditions, and values
        - Add Indian festivals, food, customs, and daily life details
        - Use Indian names, places, and cultural contexts naturally
        - Include emotional family relationships that resonate with Indian audiences
        - Add spiritual/philosophical elements common in Indian storytelling
        - Reference Indian history, mythology, or folklore where appropriate
        
        **LENGTH & DETAIL REQUIREMENTS (MINIMUM 2500 WORDS):**
        - Develop multiple plot layers and engaging subplots
        - Include detailed character backstories and motivations
        - Add vivid sensory descriptions (sounds, smells, textures, tastes)
        - Create detailed scene settings with rich cultural atmosphere
        - Include internal monologues and deep emotional exploration
        - Add meaningful conversations that reveal character personalities
        - Develop supporting characters with their own story arcs
        
        **ADDICTIVE STORYTELLING ELEMENTS:**
        - Start with a compelling hook that grabs attention immediately
        - Create cliffhangers and tension throughout the narrative
        - Add unexpected plot twists and shocking revelations
        - Include emotional peaks and valleys to maintain engagement
        - Use foreshadowing and mystery elements strategically
        - Create relatable conflicts that Indian audiences deeply connect with
        - Build curiosity and suspense in every chapter/section
        - Include dramatic moments that create strong emotional investment
        
        **OUT-OF-THE-BOX CREATIVE ELEMENTS:**
        - Incorporate unique Indian folklore, superstitions, or legends
        - Include fascinating modern-traditional culture clashes
        - Create innovative plot devices specific to Indian social context
        - Add surprising character connections or hidden family secrets
        - Include complex Indian social dynamics and hierarchies
        - Use creative metaphors from Indian culture, nature, and spirituality
        - Add unconventional narrative techniques or unique perspectives
        - Include thought-provoking themes about contemporary Indian society
        
        **STRUCTURE & QUALITY:**
        - Begin with atmospheric setting and compelling character introduction
        - Build tension gradually across multiple story layers
        - Include rich, natural dialogue that flows perfectly in {language}
        - Create smooth transitions between scenes, locations, and time periods
        - Develop multiple emotional crescendos and satisfying resolutions
        - End with the specified {ending if ending else 'memorable and impactful'} conclusion
        - Ensure every paragraph contributes meaningfully to the overall narrative
        - Include proper formatting with clear scene breaks and chapter divisions
        
        Generate a complete, professional-quality {story_type} that will captivate Indian readers from the very first line to the final word. Make it so engaging that readers cannot put it down.
        """

        # Generate content using Gemini
        try:
            if genai:
                model = genai.GenerativeModel('gemini-1.5-flash')
                response = model.generate_content(prompt)
                generated_text = response.text if response and hasattr(response, 'text') else None
            else:
                generated_text = None
        except Exception as e:
            logging.error(f"Gemini API error: {e}")
            generated_text = None
        
        if not generated_text:
            # Generate specific sample content based on story type
            if story_type == 'panchatantra':
                sample_story = f"""
**The Wise Crow and the Proud Peacock**
*A Panchatantra Tale in {language}*

**Setting:** {setting if setting else 'Ancient Indian forest near River Yamuna'}
**Moral Lesson:** True wisdom lies in humility and helping others

**The Story:**

In a beautiful forest lived Mayur, a magnificent peacock who was extremely proud of his colorful feathers. Every morning, he would spread his tail and dance, admiring his reflection in the river.

One day, an old crow named Kalu approached Mayur. "Friend," said Kalu, "there's a terrible drought coming. We must work together to find water for all the forest animals."

Mayur laughed mockingly. "Why should I, the most beautiful bird in the forest, work with an ugly black crow like you? My beauty makes me superior to everyone."

When the drought arrived, all water sources dried up. The animals were desperately thirsty. Kalu, with his intelligence and experience, knew of a hidden spring deep in the mountains. He organized all the animals to form a chain and bring water down.

Mayur, too proud to join the "common" animals, tried to find water alone. His beautiful feathers couldn't help him dig or carry water. Soon, he became extremely weak from thirst.

Seeing Mayur's condition, kind-hearted Kalu brought him water and said, "Friend, true beauty comes from helping others, not from our appearance."

**Moral:** External beauty is temporary, but inner beauty and wisdom last forever. Pride comes before a fall, and humility opens doors to friendship and success.

*This authentic Panchatantra-style story teaches valuable life lessons through engaging animal characters, perfect for Indian audiences of all ages.*
                """
            elif story_type == 'social_content':
                platform = data.get('platform', 'Multi-platform')
                content_type = data.get('contentType', 'Story Script')
                target_audience = data.get('targetAudience', 'General Indian')
                creator_name = main_character_name if main_character_name != 'protagonist' else 'Creator'
                
                # Language-specific content
                if language == 'Hindi':
                    sample_story = f"""
**भारतीय इन्फ्लूएंसर्स के लिए सोशल मीडिया कंटेंट पैकेज**
*{genre} कंटेंट {platform} के लिए हिंदी में*

**👤 मुख्य पात्र/क्रिएटर: {creator_name}**
**🎯 टारगेट ऑडियंस: {target_audience}**
**📱 प्लेटफॉर्म: {platform}**
**🎬 कंटेंट टाइप: {content_type}**

**🎬 डिटेल्ड शूटिंग स्क्रिप्ट:**

**शुरुआती हुक (0-3 सेकंड):**
*कैमरा एंगल: क्लोज़-अप शॉट*
*लाइटिंग: नेचुरल लाइट या रिंग लाइट*
"{creator_name}: नमस्ते दोस्तों! मैं {creator_name} हूं और आज जो बात मैं शेयर करने जा रहा हूं, वो आपका दिमाग हिला देगी!"

**मुख्य कंटेंट (3-45 सेकंड):**
*कैमरा मूवमेंट: मीडियम शॉट से वाइड शॉट*
*प्रॉप्स: {user_idea} के अनुसार आवश्यक सामान*
*बैकग्राउंड: इंडियन सेटिंग (घर, बाज़ार, या कल्चरल लोकेशन)*

{creator_name} की आवाज़ में: "{user_idea}"

**शूटिंग इंस्ट्रक्शन्स:**
- 0-5 सेकंड: {creator_name} का एनर्जेटिक इंट्रो
- 5-15 सेकंड: मुख्य स्टोरी का सेटअप
- 15-35 सेकंड: {creator_name} के साथ मुख्य कंटेंट
- 35-45 सेकंड: कॉल टू एक्शन

**कैमरा एंगल्स:**
1. ओपनिंग: {creator_name} का क्लोज़-अप
2. स्टोरी: ओवर-द-शोल्डर शॉट्स
3. क्लाइमैक्स: वाइड शॉट + क्लोज़-अप कॉम्बो
4. एंडिंग: {creator_name} का डायरेक्ट कैमरा शॉट

**📝 हिंदी कैप्शन पैकेज:**
"{creator_name} के साथ कहानी का समय! 🎭

{user_idea[:100]}...

यही तो मुझे भारतीय कहानियां शेयर करना पसंद है! ❤️

अपने दोस्तों को टैग करें! 👇

#{genre.replace(' ', '')}Content #IndianStories #Hindi #DesiContent #{creator_name}Stories #भारतीयकहानी #ट्रेंडिंग #देसी"

**🎬 फॉलो-अप कंटेंट आइडियाज:**
1. "{creator_name} की और भी कहानियां"
2. "बिहाइंड द सीन्स: {creator_name} के साथ"
3. "{creator_name} से प्रेरित आपकी कहानियां"
4. "{creator_name} के साथ Q&A सेशन"
5. "{creator_name} की जिंदगी के किस्से"

**📊 एंगेजमेंट स्ट्रैटेजी:**
- {creator_name} को हर कंटेंट में फीचर करें
- {creator_name} के नाम से hashtag बनाएं
- ऑडियंस से {creator_name} के बारे में सवाल पूछें
- {creator_name} के जर्नी के इर्द-गिर्द कम्युनिटी बनाएं

**🎯 शूटिंग की तैयारी:**
- लोकेशन: घर का कोना या बाहरी इंडियन सेटिंग
- कपड़े: कैजुअल इंडियन वियर
- प्रॉप्स: स्टोरी के अनुसार
- लाइटिंग: सुनहरी रोशनी (गोल्डन आवर)
- साउंड: क्लियर ऑडियो के लिए लैपल माइक

**🔥 भारतीय कल्चरल इंटीग्रेशन:**
- {creator_name} के पारंपरिक और आधुनिक दोनों पहलुओं को दिखाएं
- भारतीय पारिवारिक मूल्यों को {creator_name} के जरिए व्यक्त करें
- त्योहारों और सामाजिक मुद्दों में {creator_name} की भागीदारी दिखाएं
- {creator_name} के क्षेत्रीय बैकग्राउंड को authentic तरीके से present करें

**📊 {creator_name} ब्रांड बिल्डिंग:**
- {creator_name} का unique personality signature develop करें
- {creator_name} के नाम से trending hashtags create करें
- {creator_name} के followers के साथ personal connection build करें
- {creator_name} को Indian youth का role model बनाएं

**💰 मॉनेटाइज़ेशन स्ट्रैटेजी:**
- {creator_name} के साथ brand collaborations
- {creator_name} की merchandise opportunities
- {creator_name} के नाम से paid promotions
- {creator_name} का brand ambassador potential

*{creator_name} के साथ comprehensive Indian social media ecosystem हिंदी भाषी {target_audience.lower()} ऑडियंस के लिए*
                    """
                else:
                    sample_story = f"""
**Comprehensive Indian Social Media Ecosystem Package**
*{genre} Content for {platform} - Advanced Creator Package*

**🎭 CREATOR BRAND: {creator_name}**
**🎯 Target Audience: {target_audience}**
**📱 Platform: {platform} (Indian Algorithm Optimized)**
**🎬 Content Type: {content_type}**
**🌟 Core Concept: {user_idea}**

**🎬 MASTER SHOOTING SCRIPT (90-Second Format):**

**HOOK PHASE (0-5 seconds):**
*Camera Setup: {creator_name} close-up with Indian cultural backdrop*
*Lighting: Golden hour or ring light optimized for Indian skin tones*
*Audio: Clear Hindi-English mix characteristic of Indian creators*

{creator_name}: "Namaste friends! I'm {creator_name}, and today's story will literally give you goosebumps. Trust me, this is something every Indian needs to hear!"

**SETUP PHASE (5-20 seconds):**
*Camera Movement: Medium shot showing {creator_name} in authentic Indian environment*
*Props: Cultural items relevant to {user_idea} (Indian textiles, traditional objects, modern tech)*
*Background: Home setting that reflects middle-class Indian lifestyle*

{creator_name} narrates: "{user_idea}" with authentic Indian emotional expressions and hand gestures.

**MAIN CONTENT (20-70 seconds):**
*Multi-angle coverage featuring {creator_name} as central storyteller*
*B-roll: Authentic Indian street scenes, family moments, cultural celebrations*
*Character Integration: {creator_name} embodies every emotion and perspective in the story*

**CLIMAX & RESOLUTION (70-85 seconds):**
*Camera: Tight focus on {creator_name}'s expressive face*
*Background: Soft blur with warm Indian household lighting*
{creator_name}: "And that's why this story matters to all of us Indians..."

**CALL TO ACTION (85-90 seconds):**
*Direct eye contact with camera*
{creator_name}: "Share your thoughts! Have you experienced something similar? Tag your friends who need to see this! Follow for more real Indian stories!"

**🎨 COMPREHENSIVE PRODUCTION GUIDE:**

**1. MULTI-CAMERA SETUP:**
- Primary: {creator_name} main performance camera (face-level)
- Secondary: Wide shots showing Indian cultural context
- B-roll: Handheld for authentic documentary feel
- Backup: Phone camera for spontaneous {creator_name} reactions

**2. AUTHENTIC INDIAN PROPS INVENTORY:**
- Traditional: Diyas, rangoli materials, Indian textiles, brass items
- Modern: Smartphones, Indian snacks, regional newspapers
- Personal: Items that represent {creator_name}'s background and story
- Seasonal: Festival decorations, weather-appropriate elements

**3. WARDROBE STRATEGY FOR {creator_name}:**
- Base Look: Casual Indian wear (kurta, jeans, or Indian casual dress)
- Regional Touch: Accessories representing {creator_name}'s cultural background
- Color Palette: Warm tones that complement Indian skin and home environments
- Backup Outfits: Quick change options for different story moods

**4. LIGHTING FOR INDIAN CREATORS:**
- Primary: Warm LED panel or ring light (3200K-5600K adjustable)
- Fill: Natural window light or soft umbrella light
- Background: String lights or diyas for cultural warmth
- {creator_name} Specific: Key light positioned to enhance natural features

**5. AUDIO ECOSYSTEM:**
- Lapel mic for clear {creator_name} voice
- Background: Trending Bollywood instrumentals or Indian lo-fi beats
- Regional Touch: Subtle Indian classical elements
- Sound Effects: Authentic Indian environmental sounds

**📝 CAPTION MATRIX (10 Variations featuring {creator_name}):**

**Version 1 (Emotional):**
"{creator_name} sharing something close to the heart 💕
{user_idea[:50]}...
This is exactly why {creator_name} believes in the power of Indian stories!
Drop ❤️ if you felt this! Tag someone who needs {creator_name}'s wisdom!
#{creator_name}Stories #IndianStorytelling #AuthenticIndia #DesiWisdom"

**Version 2 (Interactive):**
"When {creator_name} tells a story, you know it's going to hit different! 🎯
{user_idea[:50]}...
Question: Have you ever experienced what {creator_name} just shared?
Comment below and let {creator_name} know your thoughts!
#{creator_name}Vibes #RealTalk #IndianExperiences #StoryTime"

**Version 3 (Community Building):**
"The {creator_name} community knows real stories when they see them! 👥
{user_idea[:50]}...
Shoutout to everyone who follows {creator_name} for authentic content!
Save this post and share {creator_name}'s message with your squad!
#{creator_name}Community #IndianInfluencer #AuthenticStories #DesiContent"

**🎬 CONTENT SERIES BLUEPRINT (20+ Ideas featuring {creator_name}):**

**Daily Series:**
1. "{creator_name}'s Morning Thoughts" - Daily wisdom series
2. "Real Talk with {creator_name}" - Honest conversation format
3. "{creator_name}'s Cultural Corner" - Indian traditions explained
4. "Behind the Scenes with {creator_name}" - Creation process content
5. "{creator_name} Reacts" - Commentary on trending Indian topics

**Weekly Specials:**
6. "{creator_name}'s Family Stories" - Multi-generational content
7. "Festival Series with {creator_name}" - Cultural celebration content
8. "{creator_name}'s Regional Spotlight" - Different Indian states/cultures
9. "Q&A Sundays with {creator_name}" - Community interaction
10. "{creator_name}'s Collaboration Corner" - Guest appearances

**📊 ENGAGEMENT ECOSYSTEM AROUND {creator_name}:**

**Community Building:**
- #{creator_name}Squad hashtag for followers
- Weekly live sessions with {creator_name}
- User-generated content challenges featuring {creator_name} themes
- Comment sections moderated to build {creator_name}'s positive community

**Brand Development:**
- {creator_name} signature catchphrases and expressions
- Consistent visual style associated with {creator_name}
- Merchandise opportunities featuring {creator_name}'s brand
- Partnership potential positioning {creator_name} as authentic Indian voice

**🔥 INDIAN CULTURAL AUTHENTICITY CHECKLIST:**

**Family Dynamics:**
- Show {creator_name} interacting with different age groups
- Include generational wisdom exchange in {creator_name}'s content
- Reference Indian joint family experiences through {creator_name}'s lens

**Regional Representation:**
- Incorporate {creator_name}'s regional background authentically
- Include local language phrases natural to {creator_name}
- Show regional festivals and customs through {creator_name}'s participation

**Modern Indian Life:**
- Balance traditional values with contemporary challenges in {creator_name}'s stories
- Address social media generation issues through {creator_name}'s perspective
- Include technology integration in typical Indian households

**💰 MONETIZATION ROADMAP FOR {creator_name}:**

**Brand Collaborations:**
- Position {creator_name} as authentic Indian lifestyle influencer
- Target brands seeking genuine Indian cultural connection
- Develop {creator_name}'s rate card based on engagement and cultural authenticity

**Product Integration:**
- Natural placement of Indian brands in {creator_name}'s content
- Regional product endorsements aligned with {creator_name}'s background
- Festival and seasonal campaign opportunities featuring {creator_name}

**Content Licensing:**
- {creator_name}'s story formats for other creators
- Cultural consultation services leveraging {creator_name}'s authenticity
- Educational content partnerships featuring {creator_name}'s storytelling

*Complete Indian social media ecosystem designed around {creator_name} as the central authentic voice for {target_audience.lower()} audience across {platform} and beyond.*
                    """
            else:
                # Extract character names for better integration
                character_names = []
                if character_descriptions:
                    character_names = [char.split(':')[0].strip() for char in character_descriptions]
                
                # Create a sample story with proper character integration
                if character_names:
                    main_character = character_names[0]
                    sample_story = f"""
**{genre} {story_type} in {language}**
*Featuring: {', '.join(character_names)}*

**Central Plot:** {user_idea}
**Setting:** {setting if setting else 'A vibrant Indian setting with rich cultural atmosphere'}
**Main Character:** {main_character} - {character_descriptions[0].split(':', 1)[1].strip() if ':' in character_descriptions[0] else 'A compelling protagonist'}

**Story Opening:**

{main_character} stood at the crossroads of destiny, unaware that the events about to unfold would change everything. In the heart of {setting if setting else 'bustling Mumbai'}, where tradition meets modernity, our story begins.

{user_idea}

**Character Development:**
{main_character} emerges as a complex character who embodies the spirit of modern India while staying rooted in cultural values. {'Along with ' + ', '.join(character_names[1:]) + ', they' if len(character_names) > 1 else 'They'} navigate through challenges that test not only their resolve but their understanding of what it means to be Indian in today's world.

**Plot Elements:**
• Character-driven narrative focusing on {main_character}'s journey
• Authentic Indian cultural references and traditions
• Emotional depth exploring family bonds and social relationships
• Engaging dialogue that brings characters to life
• Multiple plot layers creating an addictive reading experience
• Rich sensory descriptions of Indian settings and customs

**Story Arc:**
The narrative follows {main_character} through a transformative journey where {user_idea.lower()}. Each character contributes meaningfully to the plot, creating a web of relationships that drive the story forward with authentic Indian emotional depth.

**Tone & Style:** {tone if tone else 'Emotionally engaging with cultural authenticity'}
**Conclusion Style:** {ending if ending else 'Satisfying resolution that honors character growth'}

*This sample demonstrates how your characters would be seamlessly woven into a compelling {genre.lower()} {story_type} of 2500+ words, designed specifically for Indian audiences who crave authentic, character-driven storytelling.*
                    """
                else:
                    sample_story = f"""
**{genre} {story_type} in {language}**

**Central Plot:** {user_idea}
**Setting:** {setting if setting else 'A vibrant Indian setting'}

**Story Preview:**

Your detailed, lengthy, and engaging {genre.lower()} {story_type} would feature authentic Indian storytelling with:

• Rich cultural details and traditions
• Emotional family dynamics
• Engaging plot twists and character development  
• Vivid descriptions of Indian settings
• Natural dialogue in {language}
• Multiple story layers and subplots
• Addictive storytelling elements

The story would be 2500+ words of captivating content designed specifically for Indian audiences, featuring the {tone if tone else 'engaging'} tone you selected and ending with a {ending if ending else 'satisfying'} conclusion.

To generate your full story with complete character integration, please ensure the Gemini API key is properly configured in your environment settings.
                    """
            generated_text = sample_story
        
        # Create a title based on the inputs and story type
        if story_type == 'panchatantra':
            title = f"Panchatantra Tale in {language}"
        elif story_type == 'social_content':
            title = f"Social Media Content Package - {genre if genre else 'Viral'}"
        else:
            title_parts = []
            if genre:
                title_parts.append(genre)
            if story_type:
                title_parts.append(story_type.capitalize())
            if language != 'English':
                title_parts.append(f'in {language}')
            title = ' '.join(title_parts) if title_parts else f'{story_type.capitalize()}'
        
        # Save story to database
        story = Story()
        story.title = title
        story.content = generated_text
        story.language = language
        story.story_type = story_type
        story.genre = genre
        story.setting = setting
        story.tone = tone
        story.ending_style = ending
        story.user_idea = user_idea
        story.user_id = current_user.id if current_user.is_authenticated else None
        
        db.session.add(story)
        db.session.flush()  # Get the story ID
        
        # Save characters
        for char_data in characters:
            if char_data.get('name'):
                character = Character()
                character.name = char_data['name']
                character.description = char_data.get('description', '')
                character.story_id = story.id
                db.session.add(character)
        
        # Log successful generation
        generation_time = time.time() - start_time
        log_entry = GenerationLog()
        log_entry.story_id = story.id
        log_entry.prompt_used = prompt
        log_entry.generation_time = generation_time
        log_entry.success = True
        db.session.add(log_entry)
        
        db.session.commit()
        
        return jsonify({
            'script': generated_text,
            'language': language,
            'title': title,
            'story_id': story.id,
            'success': True
        })
    
    except Exception as e:
        db.session.rollback()
        generation_time = time.time() - start_time
        
        # Log failed generation
        try:
            log_entry = GenerationLog()
            log_entry.story_id = None
            log_entry.prompt_used = prompt if 'prompt' in locals() else "Error before prompt creation"
            log_entry.generation_time = generation_time
            log_entry.success = False
            log_entry.error_message = str(e)
            db.session.add(log_entry)
            db.session.commit()
        except:
            pass  # Don't fail if logging fails
        
        app.logger.error(f"Error generating script: {str(e)}")
        return jsonify({
            'error': f'An error occurred while generating your story: {str(e)}',
            'success': False
        }), 500

@app.route('/stories')
def stories_list():
    """View all generated stories"""
    from models import Story
    if current_user.is_authenticated:
        # Show user's stories
        stories = Story.query.filter_by(user_id=current_user.id).order_by(Story.created_at.desc()).limit(50).all()
    else:
        # Show recent public stories
        stories = Story.query.order_by(Story.created_at.desc()).limit(20).all()
    return render_template('stories.html', stories=stories)

@app.route('/story/<int:story_id>')
def view_story(story_id):
    """View a specific story"""
    from models import Story
    story = Story.query.get_or_404(story_id)
    return render_template('story_detail.html', story=story)

@app.route('/api/stories')
def api_stories():
    """API endpoint to get stories list"""
    from models import Story
    stories = Story.query.order_by(Story.created_at.desc()).limit(20).all()
    return jsonify([{
        'id': story.id,
        'title': story.title,
        'language': story.language,
        'genre': story.genre,
        'story_type': story.story_type,
        'created_at': story.created_at.isoformat()
    } for story in stories])

@app.errorhandler(404)
def not_found(error):
    """Handle 404 errors"""
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    """Handle 500 errors"""
    app.logger.error(f"Internal server error: {str(error)}")
    return jsonify({'error': 'Internal server error occurred'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

#!/usr/bin/env node

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

// Create a simple build script for the mobile app
console.log('Building Your Script Writer Mobile App...');

// Create package.json for mobile app
const packageJson = {
    "name": "your-script-writer-mobile",
    "version": "1.0.0",
    "description": "Your Script Writer Mobile Application - Build by Harsh Pathak",
    "main": "index.html",
    "scripts": {
        "build": "cordova build android",
        "build-release": "cordova build android --release",
        "device": "cordova run android --device",
        "emulator": "cordova run android --emulator"
    },
    "keywords": ["ai", "story", "generator", "mobile"],
    "author": "Harsh Pathak",
    "license": "MIT",
    "cordova": {
        "platforms": ["android"],
        "plugins": {
            "cordova-plugin-whitelist": {},
            "cordova-plugin-splashscreen": {},
            "cordova-plugin-network-information": {},
            "cordova-plugin-statusbar": {},
            "cordova-plugin-device": {}
        }
    },
    "devDependencies": {
        "cordova": "^12.0.0",
        "cordova-android": "^12.0.0"
    }
};

fs.writeFileSync(path.join(__dirname, 'package.json'), JSON.stringify(packageJson, null, 2));

// Create a simple icon (using SVG as placeholder)
const iconSvg = `<svg width="512" height="512" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#00d4ff;stop-opacity:1" />
      <stop offset="50%" style="stop-color:#7c3aed;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#06ffa5;stop-opacity:1" />
    </linearGradient>
  </defs>
  <rect width="512" height="512" rx="80" fill="url(#grad)"/>
  <circle cx="256" cy="180" r="60" fill="white" opacity="0.9"/>
  <circle cx="200" cy="250" r="30" fill="white" opacity="0.7"/>
  <circle cx="312" cy="250" r="30" fill="white" opacity="0.7"/>
  <circle cx="256" cy="320" r="40" fill="white" opacity="0.8"/>
  <path d="M180 350 Q256 400 332 350" stroke="white" stroke-width="8" fill="none" opacity="0.6"/>
  <text x="256" y="450" text-anchor="middle" fill="white" font-family="Arial" font-size="40" font-weight="bold">AI</text>
</svg>`;

fs.writeFileSync(path.join(__dirname, 'icon.svg'), iconSvg);

console.log('Mobile app structure created successfully!');
console.log('\nTo build the APK:');
console.log('1. cd mobile');
console.log('2. npm install');
console.log('3. cordova platform add android');
console.log('4. cordova build android');
console.log('\nAPK will be generated in: platforms/android/app/build/outputs/apk/');
# Your Script Writer Mobile App

## Overview
This directory contains the mobile application version of Your Script Writer, built using Apache Cordova to create a native Android APK. Build by Harsh Pathak.

## Prerequisites
- Node.js and npm installed
- Android SDK installed
- Java Development Kit (JDK) installed
- Cordova CLI installed globally

## Build Instructions

### 1. Install Dependencies
```bash
cd mobile
npm install
npm install -g cordova
```

### 2. Add Android Platform
```bash
cordova platform add android
```

### 3. Build APK
```bash
# Debug APK
cordova build android

# Release APK (for Play Store)
cordova build android --release
```

### 4. Find Your APK
The generated APK files will be located at:
- Debug: `platforms/android/app/build/outputs/apk/debug/app-debug.apk`
- Release: `platforms/android/app/build/outputs/apk/release/app-release-unsigned.apk`

## App Features
- Native Android app wrapper for ScriptWizard AI
- Splash screen with AI-themed design
- Embedded web view for full functionality
- Optimized for mobile devices
- Works offline for the launcher

## Configuration
- Update the web app URL in `index.html` (webAppUrl variable)
- Modify app details in `config.xml`
- Replace icons in `res/icon/` directory
- Update splash screens in `res/screen/` directory

## Deployment to Play Store
1. Sign the release APK with your keystore
2. Upload to Google Play Console
3. Complete store listing with screenshots and descriptions
4. Submit for review

## App ID
The app uses the package ID: `com.scriptwizard.ai`

## Version
Current version: 1.0.0